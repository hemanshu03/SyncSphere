from pymongo import MongoClient
import json
import os

# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')  # Replace 'localhost' with your MongoDB host if needed
db = client['SyncSphere']  # Replace 'your_database' with your database name

# Directory containing JSON files to import
input_directory = "C:\MIT WPU\TY Semester 2\Miniproject\Changes(06-02-2024)\collection_exports" 

# Get list of JSON files in the input directory
json_files = [f for f in os.listdir(input_directory) if f.endswith('.json')]

# Import each JSON file into the corresponding collection
for json_file in json_files:
    collection_name = os.path.splitext(json_file)[0]  # Extract collection name from file name
    collection = db[collection_name]

    # Read data from JSON file
    with open(os.path.join(input_directory, json_file), 'r') as f:
        data = json.load(f)

    # Insert data into collection
    collection.insert_many(data)

print("Data imported successfully.")

# Close MongoDB connection
client.close()