var socket = io.connect(location.protocol + '//' + document.domain + ':' + location.port);
socket.on('udetails', function (data) {
    if (data.result === 'success') {
        console.log("Success")
        socket.emit('redirect_to_room____')
    }
    if (data.result === 'incorrect_pswd') {
        alert(data.error || 'Incorrect Password. Please try again.');
        document.getElementById('captchaImage').src = "data:image/png;base64," + data.new_captcha_image;
        document.getElementById('captcha').value = "";
    }
    if (data.result === 'incorrect_uid') {
        alert(data.error || 'Incorrect User ID. Please try again.');
        document.getElementById('captchaImage').src = "data:image/png;base64," + data.new_captcha_image;
        document.getElementById('captcha').value = "";
    }
    if (data.result === 'incorrect_cpcha') {
        alert(data.error || 'Incorrect Captcha. Please try again.');
        document.getElementById('captchaImage').src = "data:image/png;base64," + data.new_captcha_image;
        document.getElementById('captcha').value = "";
    }
});

function storeSession() {
    sessionStorage.setItem("session_id", "{{session_id}}");
    authenticate()
}

function authenticate() {
    var sid = sessionStorage.getItem("session_id");
    fetch('/authenticate_sid', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Session-ID': sid
        }
    })
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error('Network response was not ok.');
        })
        .then(data => {
            if (data.url !== 'authentic') {
                window.location.href = data.url;
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });

}

socket.on('redirect', function (data) {
    window.location.href = data.url;
})

function hashPassword(password) {
    var shaObj = new jsSHA("SHA-512", "TEXT");
    shaObj.update(password);
    return shaObj.getHash("HEX");
}

function checkForm() {
    var requiredInputs = document.querySelectorAll('input[required]');

    var formIsValid = true;

    requiredInputs.forEach(function (input) {
        if (input.value.trim() === '') {
            formIsValid = false;
        }
    });

    if (!formIsValid) {
        alert('Please fill in all the required fields');
    }

    return formIsValid;
}

function ced() {
    var userid = document.getElementById('username').value;
    var pass__ = document.getElementById('password').value;
    var captcha_r = document.getElementById('captcha').value;
    var sessionId = sessionStorage.getItem("session_id");
    pass__ = hashPassword(pass__);

    if (checkForm()) {
        fetch('/check_entered_details', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json;charset=UTF-8'
            },
            body: JSON.stringify({
                uid: userid,
                pass__: pass__,
                captcha: captcha_r,
                session_id: sessionId
            })
        })
            .then(response => {
                if (response.ok) {
                    return response.json();
                }
                throw new Error('Network response was not ok.');
            })
            .then(data => {
                console.log(data);
                handleResponse(data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
    else {
        alert('Please fill in all the required fields');
    }
}

function handleResponse(response) {
    if (response && response.error !== undefined) {
        switch (response.error) {
            case 0:
                alert('Invalid username. Please try again.');
                break;
            case 1:
                alert('Incorrect Password. Try again.');
                break;
            case 5:
                refreshCaptcha()
                alert('Incorrect captcha. Please try again.');
                break;
            case 2:
                authenticate_user()
                break;
            case 10:
                alert('Invalid keys response. (INTERNAL SERVER ERROR)');
                break;
            default:
                alert('Unknown error');
                break;
        }
    }
    if (response && response.url !== undefined) {
        window.location.href = response.url;
    }
}

function invalidated_user() {
    console.log("Invalid user works.")
}

function authenticate_user() {
    console.log("Ok. It works.")
}

function togglePasswordVisibility() {
    // Get the password input element
    var passwordInput = document.getElementById("password");

    // Toggle the type attribute between "password" and "text"
    if (passwordInput.type === "password") {
        passwordInput.type = "text";
    } else {
        passwordInput.type = "password";
    }
}

function refreshCaptcha() {
    var sessionID = sessionStorage.getItem("session_id", "{{ session_id }}");

    fetch('/get_new_captcha', {
        method: 'GET',
        headers: {
            'X-Session-ID': sessionID
        }
    })
        .then(function (response) {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(function (data) {
            document.getElementById('captchaImage').src = "data:image/png;base64," + data.new_captcha;
            document.getElementById('captcha').value = "";
        })
        .catch(function (error) {
            console.error('Error fetching captcha:', error);
        });
}

