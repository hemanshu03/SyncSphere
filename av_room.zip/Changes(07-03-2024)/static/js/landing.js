//window.addEventListener('DOMContentLoaded', function () {
//    var logoImage = document.getElementById('logoImage');
//    var serverProvidedIcon = '{{ url_for("static", filename="images/site_logo.png") }}';
//
//    logoImage.src = serverProvidedIcon;
//});

//document.addEventListener('contextmenu', function (e) {
//    e.preventDefault();
//
//    // Display the custom context menu at the cursor position
//    const customContextMenu = document.getElementById('customContextMenu');
//    customContextMenu.style.display = 'block';
//
//    // Adjust the position based on the scroll offset
//    const scrollX = window.scrollX || window.pageXOffset;
//    const scrollY = window.scrollY || window.pageYOffset;
//
//    customContextMenu.style.left = (e.pageX - scrollX) + 'px';
//    customContextMenu.style.top = (e.pageY - scrollY) + 'px';
//
//    // Populate the custom context menu with items
//    customContextMenu.innerHTML = `
//        <ul>
//            <li onclick="customMenuItem1()">Custom Menu Item 1</li>
//            <li onclick="customMenuItem2()">Custom Menu Item 2</li>
//            <li onclick="customMenuItem3()">Custom Menu Item 3</li>
//        </ul>
//    `;
//});

// Hide the custom context menu on click outside of it
document.addEventListener('click', function () {
    const customContextMenu = document.getElementById('customContextMenu');
    customContextMenu.style.display = 'none';
});

// Define your custom menu item actions
function customMenuItem1() {
    alert('Custom Menu Item 1 clicked!');
}

function customMenuItem2() {
    alert('Custom Menu Item 2 clicked!');
}

function customMenuItem3() {
    alert('Custom Menu Item 3 clicked!');
}
