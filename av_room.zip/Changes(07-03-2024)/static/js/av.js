const localVideoContainer = document.getElementById('localVideoContainer');
const remoteVideos = document.getElementById('remoteVideos');
const muteButton = document.getElementById('muteButton');
const cameraButton = document.getElementById('cameraButton');
const screenShareButton = document.getElementById('screenShareButton');
const permissionDenied = document.getElementById('permissionDenied');
const inviteButton = document.getElementById('inviteButton');
const inviteLinkInput = document.getElementById('inviteLink');

let localStream;

async function getUserMedia() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localStream = stream;
    const localVideo = document.createElement('video');
    localVideo.srcObject = stream;
    localVideo.autoplay = true;
    localVideo.classList.add('video');
    localVideoContainer.appendChild(localVideo);
    setInitialButtonState();
    muteButton.addEventListener('click', toggleMute);
    cameraButton.addEventListener('click', toggleCamera);
    screenShareButton.addEventListener('click', toggleScreenSharing);
    generateInviteLink();
  } catch (error) {
    console.error('Error accessing media devices:', error);
    permissionDenied.style.display = 'block';
  }
}

function setInitialButtonState() {
  if (localStream) {
    muteButton.textContent = localStream.getAudioTracks()[0].enabled ? 'Mute' : 'Unmute';
    cameraButton.textContent = localStream.getVideoTracks()[0].enabled ? 'Turn Off Camera' : 'Turn On Camera';
  }
}

function toggleMute() {
  if (localStream) {
    localStream.getAudioTracks().forEach(track => {
      track.enabled = !track.enabled;
    });
    muteButton.textContent = localStream.getAudioTracks()[0].enabled ? 'Mute' : 'Unmute';
  }
}

function toggleCamera() {
  if (localStream) {
    localStream.getVideoTracks().forEach(track => {
      track.enabled = !track.enabled;
    });
    cameraButton.textContent = localStream.getVideoTracks()[0].enabled ? 'Turn Off Camera' : 'Turn On Camera';
  }
}

async function toggleScreenSharing() {
  try {
    const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
    const screenTrack = screenStream.getVideoTracks()[0];
    const audioTrack = localStream.getAudioTracks()[0];
    localStream.addTrack(screenTrack);
    localStream.addTrack(audioTrack);
    screenShareButton.textContent = 'Stop Sharing Screen';
    screenShareButton.removeEventListener('click', toggleScreenSharing);
    screenShareButton.addEventListener('click', stopScreenSharing);
  } catch (error) {
    console.error('Error accessing screen sharing:', error);
  }
}

function stopScreenSharing() {
  const screenTrack = localStream.getVideoTracks().find(track => track.kind === 'video');
  localStream.removeTrack(screenTrack);
  screenShareButton.textContent = 'Share Screen';
  screenShareButton.removeEventListener('click', stopScreenSharing);
  screenShareButton.addEventListener('click', toggleScreenSharing);
}

inviteButton.addEventListener('click', generateInviteLink);

function generateInviteLink() {
  const meetingId = generateMeetingId();
  const inviteLink = window.location.origin + '/join?meetingId=' + meetingId;
  inviteLinkInput.value = inviteLink;
}

function generateMeetingId() {
  const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
  return uuid;
}

getUserMedia();
