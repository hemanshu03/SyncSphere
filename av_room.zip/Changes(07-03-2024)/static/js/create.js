var socket = io.connect(location.protocol + '//' + document.domain + ':' + location.port);

socket.on('redirect', function (data) {
    window.location.href = data.url;
});

const validDomains = {
    'gmail.com': true,
    'yahoo.org': true,
    'rediffmail.com': true,
    'mitwpu.edu.in': true,
};

function validateEmail() {
    var email = document.getElementById('email-full').value
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
        return false;
    }
    const [, domain] = email.split('@');
    if (validDomains[domain] === true) {
        sessionStorage.setItem('email', email);
        sendOtp(email)
    }
}

socket.on('validation_result', function (data) {
    if (data.result === 'incorrect') {
        alert(data.error || 'Incorrect Captcha. Please try again.');
        refreshCaptcha();
    }
});

function hashPassword(password) {
    var shaObj = new jsSHA("SHA-512", "TEXT");
    shaObj.update(password);
    return shaObj.getHash("HEX");
}

function checkUsername() {
    var username = document.getElementById("username").value;
    socket.emit('check_username', { username: username });
    document.querySelector("#initial-form button").disabled = true;
    return false;
}

socket.on('usnm_verification_status', function (data) {
    document.querySelector("#initial-form button").disabled = false;
    if (data.exists) {
        alert("Username already exists. Please choose another.");
    } else {
        var username = document.getElementById('username').value;
        sessionStorage.setItem('username', username);
        Email_veriForm();
    }
});

function Email_veriForm() {
    var initialForm = document.getElementById('initial-form');
    var emailForm = document.getElementById('email-form');
    if (initialForm && emailForm) {
        initialForm.style.display = 'none';
        emailForm.style.display = 'block';

        var usernameInput = document.getElementById('username-full');

        if (usernameInput) {
            usernameInput.value = sessionStorage.getItem('username');;
        }
    }
}

function get_session() {
    // Create a URL object
    var url = window.location.href;

    // Extract the session_id parameter from the URL
    var sessionIdIndex = url.indexOf("session_id%3F=");

    if (sessionIdIndex !== -1) {
        // Adjust the index to get the actual value
        sessionIdIndex += "session_id%3F=".length;

        // Find the end index of the session ID
        var endIndex = url.indexOf("&", sessionIdIndex);
        if (endIndex === -1) {
            endIndex = url.length;
        }

        // Extract the session ID
        var sessionId = url.substring(sessionIdIndex, endIndex);

        // Decode the session ID if needed
        sessionId = decodeURIComponent(sessionId);
    }
    return sessionId
}

function sendOtp(email) {
    socket.emit('send_otp', { email: email });
    loadOtpVerificationForm()
}

function togglePasswordVisibility() {
    var passwordInput = document.getElementById("password");
    if (passwordInput) {
        passwordInput.type = passwordInput.type === "password" ? "text" : "password";
    }
}

function loadOtpVerificationForm() {
    var initialForm = document.getElementById('initial-form');
    var otpForm = document.getElementById('otp-veri');

    if (initialForm && otpForm) {
        initialForm.style.display = 'none';
        otpForm.style.display = 'block';

        var usernameInput = document.getElementById('username-full');
        var emailInput = document.getElementById('email-full');

        if (usernameInput) {
            usernameInput.value = sessionStorage.getItem('username');
        }

        if (emailInput) {
            emailInput.value = sessionStorage.getItem('email');
        }
    }
}

function refreshCaptcha() {
    var sessionID = sessionStorage.getItem("session_id", "{{ session_id }}");

    fetch('/get_new_captcha', {
        method: 'GET',
        headers: {
            'X-Session-ID': sessionID
        }
    })
        .then(function (response) {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(function (data) {
            document.getElementById('captchaImage').src = "data:image/png;base64," + data.new_captcha;
            document.getElementById('captcha').value = "";
        })
        .catch(function (error) {
            console.error('Error fetching captcha:', error);
        });
}

function loadFullRegistrationForm() {
    var initialForm = document.getElementById('initial-form');
    var otpForm = document.getElementById('otp-veri');
    var emailForm = document.getElementById('email-form')
    if (otpForm) {
        otpForm.style.display = 'none';
    }
    if (initialForm) {
        initialForm.style.display = 'none';
    }
    if (emailForm) {
        emailForm.style.display = 'none';
    }
    var fullRegistrationForm = document.getElementById('v-full-registration-form');
    if (fullRegistrationForm) {
        fullRegistrationForm.style.display = 'block';
        var usernameInput = document.getElementById('username-full_');
        var emailInput = document.getElementById('email-full_');
        if (usernameInput && emailInput) {
            usernameInput.value = sessionStorage.getItem('username');
            emailInput.value = sessionStorage.getItem('email');
        }
    }
}

function validateForm() {
    var username = document.getElementById("username-full_").value;
    var email = document.getElementById("email-full_").value;
    var password = document.getElementById("password").value;
    var captcha_r = document.getElementById("captcha").value;

    password = hashPassword(password);

    socket.emit('register_user', { usr: username, eml: email, psrd: password, captcha_: captcha_r });
}

socket.on('invalid_session', function (data) {
    if (data.invalid_session) {
        alert('Server reported this session ID is invalid. Please start over.');
        socket.emit('redirect_to_landing____');
    }
})

function clear_browser() {
    document.cookie.split(";").forEach(function (c) {
        document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
    });
    window.sessionStorage.clear();
    window.localStorage.clear();
}

socket.on('registration_status', function (data) {
    if (data.isfailed) {
        alert('Sent data was not valid. Please try again by repeating the process.');
        socket.on('redirect_to_landing____');
    }
    if (!data.isfailed) {
        alert('Your account has been registered successfully!');
        window.location.href = '/login';
    }
});

socket.on('redirect', function (data) {
    window.location.href = data.url;
});

function validateOtp() {
    var otpValue = document.getElementById('otp__').value;
    var session_id = get_session()
    socket.emit('validate_otp', { otp: otpValue, session_id: session_id });
}

socket.on('otp_verification', function (data) {
    if (!data.result && !data.error) {
        alert('E-mail ID could not be verified. Wrong OTP entered.');
        socket.emit('redirect_to_landing____');
    }
    if (!data.result && data.error) {
        alert('Some error occured. Please try again.');
        socket.emit('redirect_to_landing____');
    }
    if (data.result && !data.error) {
        alert('E-mail ID verified successfully!');
        loadFullRegistrationForm();
    }
});

